<?php $__env->startSection('content'); ?>
    <div class="parent">
        <div class="block">
            <div class="panel panel-success">
                <div class="panel-heading">Url data</b></div>
                <div class="panel-body">
                    <ul class="list-group">
                            <li>Original url: <?php echo e($url_original); ?></li>
                            <li>New url: <a href="<?php echo e($url_changed); ?>" target="_blank"><?php echo e($url_changed); ?></a></li>
                            <li>Password:
                                <?php if($password != ''): ?>
                                    <?php echo e($password); ?>

                                <?php else: ?>
                                    Not
                                <?php endif; ?>
                            </li>
                    </ul>
                </div>
            </div>
            <a href="javascript:void(0)" onclick="window.history.back();"><< Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>