<?php $__env->startSection('content'); ?>
    <div class="parent">
        <div class="block">
            <div class="panel panel-danger">
                <div class="panel-heading">Errors</b></div>
                <div class="panel-body">
                    <ul>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>
            </div>
            <a href="javascript:void(0)" onclick="window.history.back();"><< Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>