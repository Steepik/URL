@extends('app')

@section('content')

<div class="comingcontainer">
    <div class="checkbacksoon">
        <p>
            <span class="go3d">4</span>
            <span class="go3d">0</span>
            <span class="go3d">4</span>
            <span class="go3d">!</span>

        </p>

        <p class="error">Данная страница не найдена.</p>

    </div>
</div>
@stop